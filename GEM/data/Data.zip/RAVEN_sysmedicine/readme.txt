-The RAVEN Toolbox version 1.08
2014-01-06

The RAVEN Toolbox is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. The latest version of the RAVEN Toolbox can be found at http://sysbio.se/BioMet. Please contact rasmus.j.agren@gmail.com if you have any questions.